package com.example.proyectorecycled


    data class Person(val name: String, val surname:String)


